#ifndef DOUBLELINKEDLIST_H
#define DOUBLELINKEDLIST_H

#include <stdio.h>

/**
 * Node in a double linked list, containing a generic pointer to any type of item, a pointer to the next node and a pointer to the previous node.
 */
typedef struct DoubleLinkedList {
    void *item; /**< Pointer to the item stored in the node. */
    struct DoubleLinkedList *next; /**< Pointer to the next node in the list. */
    struct DoubleLinkedList *prev; /**< Pointer to the previous node in the list. */
} DoubleLinkedList;

/**
 * Adds a new item to the beginning of the list.
 *
 * @param node Pointer to the first node in the list.
 * @param item Pointer to the item to add to the list.
 */
void addToDoubleList(DoubleLinkedList **node, void *item);

/**
 * Removes the first occurrence of an item from the list that matches the target, based on a comparison function.
 *
 * @param node Pointer to the first node in the list.
 * @param compare Function used to compare two list items.
 * @param item Pointer to the target item to remove from the list.
 * @return Pointer to the removed item, or NULL if the item was not found.
 */
void *removeFromDoubleList(DoubleLinkedList **node, int (*compare)(void *, void *), void *item);

/**
 * Finds an item in the list that matches the target, based on a comparison function.
 *
 * @param node Pointer to the first node in the list.
 * @param compare Function used to compare two list items.
 * @param item Pointer to the target item to find in the list.
 * @return Pointer to the found item, or NULL if the item was not found.
 */
void *findInDoubleList(const DoubleLinkedList *node, int (*compare)(void *, void *), void *item);

/**
 * Returns the number of items in the list.
 *
 * @param node Pointer to the first node in the list.
 * @return The number of items in the list.
 */
int sizeOfDoubleList(const DoubleLinkedList *node);

/**
 * Iterates over each item in the list and applies a given function, such as printing or modifying items.
 *
 * @param node Pointer to the first node in the list.
 * @param printItem Function applied to each item in the list.
 */
void printDoubleList(const DoubleLinkedList *node, void (*printItem)(const void *));

/**
 * Saves the contents of a double linked list to a binary file, using a given function to save each item.
 *
 * @param file Pointer to the file to save the list to.
 * @param node Pointer to the first node in the list to save.
 * @param saveItem Function used to save each item in the list.
 * @return 1 if the list is successfully saved, 0 otherwise.
 */
int saveDoubleListBinary(FILE *file, const DoubleLinkedList *node, int (*saveItem)(FILE *, const void *));

/**
 * Loads a double linked list from a binary file, using a given function to load each item.
 *
 * @param node Pointer to the first node in the list to load into.
 * @param file Pointer to the file to load the list from.
 * @param loadItem Function used to load each item from the file.
 * @return 1 if the list is successfully loaded, 0 otherwise.
 */
int loadDoubleListBinary(FILE *file, DoubleLinkedList **node, void * (*loadItem)(FILE *));

/**
 * Saves the contents of a double linked list to a file, using a given function to save each item.
 *
 * @param file Pointer to the file to save the list to.
 * @param node Pointer to the DoubleLinkedList structure to save.
 * @param saveItem Function used to save each item in the list.
 */
void saveDoubleList(FILE *file, const DoubleLinkedList *node, void (*saveItem)(FILE *, const void *));

/**
 * Loads a double linked list from a file, using a given function to load each item.
 *
 * @param file Pointer to the file to load the list from.
 * @param loadItem Function used to load each item from the file.
 * @return Pointer to the loaded DoubleLinkedList structure.
 */
DoubleLinkedList *loadDoubleList(FILE *file, void * (*loadItem)(FILE *));

/**
 * Frees the memory allocated for a double linked list and its items.
 *
 * @param node Pointer to the first node in the list.
 * @param freeItem Function used to free the memory allocated for an item, if necessary. Can be NULL.
 */
void freeDoubleList(DoubleLinkedList **node, void (*freeItem)(void *));

#endif // DOUBLELINKEDLIST_H
