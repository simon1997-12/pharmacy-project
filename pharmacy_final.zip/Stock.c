#define _CRT_SECURE_NO_WARNINGS
#include "Stock.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

typedef int (*ArrayItemFunction)(void *, void *);

int iterateArray(void *array, const int size, const int n, ArrayItemFunction operation, void *arg) {
    for (int i = 0; i < n; i++) {
        if (operation((char *) array + i * size, arg) != 1) {
            return 0;
        }
    }
    return 1;
}

void initStock(Stock *stock) {
    stock->lastProductCode = 0;
    stock->products = NULL;
    stock->productCount = 0;
    stock->medicines = NULL;
    stock->medicineCount = 0;
}

int OperationPrintProduct(Product *product, void *arg) {
    printProductDetails(product);
    return 1;
}

void sortProductInStock(Stock *stock) {
    int option;
    if (stock->productCount == 0) {
        printf("No products to sort.\n");
        return;
    }

    printf("Enter sort option (1 - by code, 2 - by name, 3 - by price): ");
    scanf("%d", &option);
    switch (option) {
        case 1:
            qsort(stock->products, stock->productCount, sizeof(Product), compareProductByID);
            printf("Available Products After Sorting By Id:\n");
            iterateArray((void *) stock->products, sizeof(Product), stock->productCount,
                         (ArrayItemFunction) OperationPrintProduct,NULL);
            break;
        case 2:
            qsort(stock->products, stock->productCount, sizeof(Product), compareProductByName);
            printf("Available Products After Sorting By Name:\n");
            iterateArray((void *) stock->products, sizeof(Product), stock->productCount,
                         (ArrayItemFunction) OperationPrintProduct,NULL);
            break;
        case 3:
            qsort(stock->products, stock->productCount, sizeof(Product), compareProductByPrice);
            printf("Available Products After Sorting By Price:\n");
            iterateArray((void *) stock->products, sizeof(Product), stock->productCount,
                         (ArrayItemFunction) OperationPrintProduct,NULL);
            break;
        default:
            printf("Invalid sort type.\n");
    }
}

void findProductInStockBSearch(Stock *stock) {
    int option;
    Product *product = (Product *) malloc(sizeof(Product));
    if (product == NULL) {
        printf("Memory allocation failed for product.\n");
        return;
    }

    product->name = NULL;

    if (stock->productCount == 0) {
        printf("No products to search.\n");
        free(product);
        return;
    }

    printf("Enter search option (1 - by code, 2 - by name, 3 - by price): ");
    scanf("%d", &option);
    clearInputBuffer();
    switch (option) {
        case 1:
            printf("Enter product code to search: ");
            scanf("%d", &product->code);
            clearInputBuffer();
            qsort(stock->products, stock->productCount, sizeof(Product), compareProductByID);
            Product *foundProduct = (Product *) bsearch(product, stock->products, stock->productCount, sizeof(Product),
                                                        compareProductByID);
            if (foundProduct != NULL) {
                printProductDetails(foundProduct);
            } else {
                printf("Product with code %d not found.\n", product->code);
            }
            break;
        case 2:
            printf("Enter product name to search: ");
            char buffer[BUFFER_SIZE];
            myGets(buffer);
            product->name = (char *) malloc(strlen(buffer) + 1);
            strcpy(product->name, buffer);
            qsort(stock->products, stock->productCount, sizeof(Product), compareProductByName);
            Product *foundProductByName = (Product *) bsearch(product, stock->products, stock->productCount,
                                                              sizeof(Product), compareProductByName);
            if (foundProductByName != NULL) {
                printProductDetails(foundProductByName);
            } else {
                printf("Product with name %s not found.\n", product->name);
            }

            free(product->name);

            break;
        case 3:
            printf("Enter product price to search: ");
            scanf("%lf", &product->price);
            clearInputBuffer();
            qsort(stock->products, stock->productCount, sizeof(Product), compareProductByPrice);
            Product *foundProductByPrice = (Product *) bsearch(product, stock->products, stock->productCount,
                                                               sizeof(Product), compareProductByPrice);
            if (foundProductByPrice != NULL) {
                printProductDetails(foundProductByPrice);
            } else {
                printf("Product with price %.2f not found.\n", product->price);
            }
            break;
        default:
            printf("Invalid search type.\n");
            break;
    }

    free(product);
}

// Comparator for medicines by ID
int compareMedicineByID(const void *a, const void *b) {
    const Medicine *medA = (const Medicine *) a;
    const Medicine *medB = (const Medicine *) b;
    return strcmp(medA->medicineID, medB->medicineID);
}

// Comparator for products by code
int compareProductByID(const void *a, const void *b) {
    const Product *productA = (const Product *) a;
    const Product *productB = (const Product *) b;
    return productA->code - productB->code;
}

// Comparator for products by name
int compareProductByName(const void *a, const void *b) {
    const Product *productA = (const Product *) a;
    const Product *productB = (const Product *) b;
    return strcmp(productA->name, productB->name);
}

// Comparator for products by price
int compareProductByPrice(const void *a, const void *b) {
    const Product *productA = (const Product *) a;
    const Product *productB = (const Product *) b;
    return productA->price - productB->price;
}

Product *findProduct(const Stock *stock, int code) {
    // Use Binary Search to find the product with the given code
    Product tmp;
    tmp.code = code;
    qsort(stock->products, stock->productCount, sizeof(Product), compareProductByID);
    Product *found = (Product *) bsearch(&tmp, stock->products, stock->productCount, sizeof(Product),
                                         compareProductByID);
    return found;
}

int compareMedicineByCode(const void *a, const void *b) {
    const Medicine *medA = (const Medicine *) a;
    const Medicine *medB = (const Medicine *) b;
    return medA->product.code - medB->product.code;
}

Medicine *findMedicine(const Stock *stock, int code) {
    // Use Binary Search to find the medicine with the given code
    Medicine tmp;
    tmp.product.code = code;
    qsort(stock->medicines, stock->medicineCount, sizeof(Medicine), compareMedicineByCode);
    Medicine *found = (Medicine *) bsearch(&tmp, stock->medicines, stock->medicineCount, sizeof(Medicine),
                                           compareMedicineByCode);
    return found;
}

Medicine *findMedicineByID(Stock *stock, const char *medicineID) {
    // Use Binary Search to find the medicine with the given ID
    Medicine tmp;
    strcpy(tmp.medicineID, medicineID);
    qsort(stock->medicines, stock->medicineCount, sizeof(Medicine), compareMedicineByID);
    Medicine *found = (Medicine *) bsearch(&tmp, stock->medicines, stock->medicineCount, sizeof(Medicine),
                                           compareMedicineByID);
    return found;
}

void addNewProductToStock(Stock *stock) {
    Product *newProduct = (Product *) malloc(sizeof(Product));
    if (newProduct == NULL) {
        printf("Memory allocation failed for new product.\n");
        return;
    }

    initProduct(newProduct, 0, ++stock->lastProductCode); // 0 indicating this is not a medicine
    // Add the new product to the products array
    stock->products = (Product *) realloc(stock->products, (stock->productCount + 1) * sizeof(Product));
    CHECK_ALLOC_VOID(stock->products);
    stock->products[stock->productCount] = *newProduct;
    stock->productCount++;
}

void addNewMedicineToStock(Stock *stock) {
    Medicine *existingMedicine = NULL;
    char medicineID[MEDICINE_ID_LENGTH + 1];

    char buffer[BUFFER_SIZE];

    do {
        printf("Enter unique Medicine ID (6 digits): ");
        myGets(buffer);

        if (strlen(buffer) > MEDICINE_ID_LENGTH) {
            printf("Medicine ID must be %d digits long.\n", MEDICINE_ID_LENGTH);
            continue;
        }

        strcpy(medicineID, buffer);

        // Use findMedicineByID to check if a medicine with the given ID already exists
        existingMedicine = findMedicineByID(stock, medicineID);

        if (existingMedicine != NULL) {
            printf("A medicine with the ID %s already exists in stock. Please enter a different ID.\n", medicineID);
        }
    } while (existingMedicine != NULL); // Repeat until a unique ID is provided

    // Proceed to add new medicine if no existing medicine with the same ID is found
    Medicine *newMedicine = (Medicine *) malloc(sizeof(Medicine));
    CHECK_ALLOC_VOID(newMedicine);

    // Initialize new medicine with the provided ID
    initMedicine(newMedicine, medicineID, ++stock->lastProductCode);

    // Add the new medicine to the medicines array
    stock->medicines = (Medicine *) realloc(stock->medicines, (stock->medicineCount + 1) * sizeof(Medicine));
    CHECK_ALLOC_VOID(stock->medicines);
    stock->medicines[stock->medicineCount] = *newMedicine;
    stock->medicineCount++;
}

int OperationPrintMedicine(Medicine *medicine, void *arg) {
    printMedicineDetails(medicine);
    return 1;
}

void printStockDetails(const Stock *stock) {
    printf("Available Products:\n");
    iterateArray((void *) stock->products, sizeof(Product), stock->productCount,
                 (ArrayItemFunction) OperationPrintProduct,NULL);

    printf("Available Medicines:\n");
    iterateArray((void *) stock->medicines, sizeof(Medicine), stock->medicineCount,
                 (ArrayItemFunction) OperationPrintMedicine,NULL);
}

void decreaseStockQuantity(Stock *stock, int productCode, int quantity) {
    // Find the product in the stock
    Product *stockProduct = findProduct(stock, productCode);

    if (stockProduct != NULL) {
        // Update the quantity available in the stock
        stockProduct->stockQuantity -= quantity;
    } else {
        // Handle the case where the product is not found in the stock
        Medicine *stockMedicine = findMedicine(stock, productCode);
        if (stockMedicine != NULL) {
            // Update the quantity available in the stock
            stockMedicine->product.stockQuantity -= quantity;
        } else {
            printf("Product code %d not found in stock.\n", productCode);
        }
    }
}

void updateStock(Stock *stock, int productCode, int quantity) {
    // Find the product in the stock
    Product *stockProduct = findProduct(stock, productCode);

    if (stockProduct != NULL) {
        // Update the quantity available in the stock
        stockProduct->stockQuantity = quantity;
    } else {
        Medicine *stockMedicine = findMedicine(stock, productCode);
        if (stockMedicine != NULL) {
            // Handle the case where the product is a medicine
            stockMedicine->product.stockQuantity = quantity;
        } else {
            // Handle the case where the product is not found in the stock
            printf("Product code %d not found in stock.\n", productCode);
        }
    }
}

void updateMedicineStock(Stock *stock, char *medicineID, int quantity) {
    // Find the product in the stock
    Medicine *stockMedicine = findMedicineByID(stock, medicineID);

    if (stockMedicine != NULL) {
        // Update the quantity available in the stock
        if (stockMedicine->product.stockQuantity >= quantity) {
            stockMedicine->product.stockQuantity -= quantity;
        } else {
            // Handle the case where there's not enough stock
            printf("Insufficient stock for medicine with ID %s. Available: %d, Required: %d\n", medicineID,
                   stockMedicine->product.stockQuantity, quantity);
        }
    } else {
        // Handle the case where the product is not found in the stock
        printf("Medicine with the ID %s not found in stock.\n", medicineID);
    }
}

int OperationSaveProductToBinary(void *product, void *arg) {
    FILE *file = (FILE *) arg;
    return saveProductToBinary(file, (Product *) product);
}

int saveProductsToBinary(FILE *file, const Product *products, int productCount) {
    if (fwrite(&productCount, sizeof(int), 1, file) != 1) {
        return 0;
    }

    if (!iterateArray((void *) products, sizeof(Product), productCount, OperationSaveProductToBinary, file)) {
        return 0;
    }

    return 1;
}

int OperationSaveMedicineToBinary(void *medicine, void *arg) {
    FILE *file = (FILE *) arg;
    return saveMedicineToBinary(file, (Medicine *) medicine);
}

int saveMedicinesToBinary(FILE *file, const Medicine *medicines, int medicineCount) {
    if (fwrite(&medicineCount, sizeof(int), 1, file) != 1) {
        return 0;
    }

    if (!iterateArray((void *) medicines, sizeof(Medicine), medicineCount, OperationSaveMedicineToBinary, file)) {
        return 0;
    }

    return 1;
}

int saveStockToBinary(const Stock *stock, FILE *file) {
    if (fwrite(&stock->lastProductCode, sizeof(int), 1, file) != 1) {
        return 0;
    }

    // Save the products
    if (!saveProductsToBinary(file, stock->products, stock->productCount)) {
        return 0;
    }

    // Save the medicines
    if (!saveMedicinesToBinary(file, stock->medicines, stock->medicineCount)) {
        return 0;
    }

    return 1;
}

int OperationLoadProductFromBinary(void *product, void *arg) {
    FILE *file = (FILE *) arg;
    *(Product *) product = *loadProductFromBinary(file);
    return 1;
}


int loadProductsFromBinary(FILE *file, Stock *stock) {
    if (fread(&stock->productCount, sizeof(int), 1, file) != 1) {
        printf("Error reading product count from file.\n");
        return 0;
    }

    stock->products = (Product *) malloc(stock->productCount * sizeof(Product));
    CHECK_ALLOC_INT(stock->products);

    iterateArray((void *) stock->products, sizeof(Product), stock->productCount, OperationLoadProductFromBinary, file);

    return 1;
}

int OperationLoadMedicineFromBinary(void *medicine, void *arg) {
    FILE *file = (FILE *) arg;
    *(Medicine *) medicine = *loadMedicineFromBinary(file);
    return 1;
}

int loadMedicinesFromBinary(FILE *file, Stock *stock) {
    if (fread(&stock->medicineCount, sizeof(int), 1, file) != 1) {
        printf("Error reading medicine count from file.\n");
        return 0;
    }

    stock->medicines = (Medicine *) malloc(stock->medicineCount * sizeof(Medicine));
    CHECK_ALLOC_INT(stock->medicines);

    iterateArray((void *) stock->medicines, sizeof(Medicine), stock->medicineCount, OperationLoadMedicineFromBinary,
                 file);

    return 1;
}

int loadStockFromBinary(FILE *file, Stock *stock) {
    initStock(stock);

    // Load the last product code
    if (fread(&stock->lastProductCode, sizeof(int), 1, file) != 1) {
        printf("Error reading last product code from file.\n");
        return 0;
    }

    // Load the products
    if (!loadProductsFromBinary(file, stock))
        return 0;

    // Load the medicines
    if (!loadMedicinesFromBinary(file, stock))
        return 0;

    return 1;
}

int OperationSaveProduct(void *product, void *arg) {
    FILE *file = (FILE *) arg;
    saveProduct(file, (Product *) product);
    return 1;
}

void saveProducts(FILE *file, const Product *products, int productCount) {
    fprintf(file, "%d\n", productCount);
    iterateArray((void *) products, sizeof(Product), productCount, OperationSaveProduct, file);
}

int OperationSaveMedicine(void *medicine, void *arg) {
    FILE *file = (FILE *) arg;
    saveMedicine(file, (Medicine *) medicine);
    return 1;
}

void saveMedicines(FILE *file, const Medicine *medicines, int medicineCount) {
    fprintf(file, "%d\n", medicineCount);
    iterateArray((void *) medicines, sizeof(Medicine), medicineCount, OperationSaveMedicine, file);
}

void saveStock(const Stock *stock, FILE *file) {
    fprintf(file, "%d\n", stock->lastProductCode);
    // Save the products
    saveProducts(file, stock->products, stock->productCount);

    // Save the medicines
    saveMedicines(file, stock->medicines, stock->medicineCount);
}

int OperationLoadProduct(void *product, void *arg) {
    FILE *file = (FILE *) arg;
    *(Product *) product = *loadProduct(file);
    return 1;
}

void loadProducts(FILE *file, Stock *stock) {
    fscanf(file, "%d\n", &stock->productCount);

    stock->products = (Product *) malloc(stock->productCount * sizeof(Product));
    CHECK_ALLOC_VOID(stock->products);

    iterateArray((void *) stock->products, sizeof(Product), stock->productCount, OperationLoadProduct, file);
}

int OperationLoadMedicine(void *medicine, void *arg) {
    FILE *file = (FILE *) arg;
    *(Medicine *) medicine = *loadMedicine(file);
    return 1;
}

void loadMedicines(FILE *file, Stock *stock) {
    fscanf(file, "%d\n", &stock->medicineCount);

    stock->medicines = (Medicine *) malloc(stock->medicineCount * sizeof(Medicine));
    CHECK_ALLOC_VOID(stock->medicines);

    iterateArray((void *) stock->medicines, sizeof(Medicine), stock->medicineCount, OperationLoadMedicine, file);
}

void loadStock(FILE *file, Stock *stock) {
    initStock(stock);

    fscanf(file, "%d\n", &stock->lastProductCode);

    // Load the products
    loadProducts(file, stock);

    // Load the medicines
    loadMedicines(file, stock);
}


void freeStockProducts(Stock *stock) {
    free(stock->products);
    stock->products = NULL;
    stock->productCount = 0;
}

void freeStockMedicines(Stock *stock) {
    free(stock->medicines);
    stock->medicines = NULL;
    stock->medicineCount = 0;
}

void freeStock(Stock *stock) {
    freeStockProducts(stock);
    freeStockMedicines(stock);
}
