# Project Requirements

## Mandatory Components of the System:

- [x] The project must include at least 8 structures (Date and/or Address
   types do not count):

    - [x] A structure that describes the main entity of the system.

    - [x] A structure that can hold another structure as an array of
      pointers of unknown size.

    - [x] A structure that can hold another structure as an array of
      unknown size.

    - [x] At least one structure must contain a variable of type char\*.

    - [x] At least one structure must contain a char variable of fixed
      and known size.

    - [x] At least one structure must include another structure without
      using a pointer (Date and/or Address structures do not count) --
      Struct inside Struct.

    - [x] At least one structure must include another structure as a
      pointer.

    - [x] At least one structure must include a linked list that holds a
      pointer of type void\* to a structure.

    - [x] At least one structure must include a doubly linked list
      without a header.

- [x] The system data must be saved in text files.

- [x] The system data must be saved in binary files, with at least one
   structure being compressed in the binary file (Date and Address
   structures do not count). The structure must contain at least 4
   fields.

- [x] The project must allow sorting an array using qsort based on at
   least 3 different properties of different variable types.

- [x] The project must allow searching the same array using bsearch based
   on at least 3 different properties of different variable types.

- [x] Implement a general function that receives an array of type void\*
   and use it in at least 3 places in the code, including at least one
   function that prints and one that frees memory.

- [x] Create at least one #define macro (preferably for printing) and use
   it in the project.

- [x] Main menu should allow the following:

    - [x] Load the system from a text or binary file as chosen by the
      user.

    - [x] Display the system on the screen.

    - [x] Display subcomponents of the system on the screen.

    - [x] Add components to the system.

    - [x] Sort.

    - [x] Search.

    - [x] At least two additional creative actions (three additional
      actions for group projects).

## Project Review Checklist:

- [ ] Compilation without warnings.

- [ ] Full implementation of project requirements.

- [ ] Execution without crashes.

- [ ] Memory leak detection.

- [ ] Interesting capabilities in the main menu.

- [ ] Correct use of pointers.

- [ ] Correct use of const.

- [ ] Verification of dynamic memory allocation.

- [ ] Function return value checks.

- [ ] File open/close handling.

- [ ] Efficient storage in binary files.

- [ ] void\* functions as required.

- [ ] Modular code (file and function division).

- [ ] Clear and simple code.

- [ ] Efficient code.

- [ ] Concise and professional report.

- [ ] System diagram.

- [ ] Submission of files as required.
