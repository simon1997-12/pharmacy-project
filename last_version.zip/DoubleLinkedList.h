#ifndef DOUBLELINKEDLIST_H
#define DOUBLELINKEDLIST_H

#include <stdio.h>
#define SUCCESSDOUBLE 1

typedef struct DoubleLinkedList {
    void *item; 
    struct DoubleLinkedList *next; 
    struct DoubleLinkedList *prev; 
} DoubleLinkedList;


void addToDoubleList(DoubleLinkedList **node, void *item);

void *removeFromDoubleList(DoubleLinkedList **node, int (*compare)(void *, void *), void *item);

void *findInDoubleList(const DoubleLinkedList *node, int (*compare)(void *, void *), void *item);

int sizeOfDoubleList(const DoubleLinkedList *node);

void printDoubleList(const DoubleLinkedList *node, void (*printItem)(const void *));

int saveDoubleListBinary(FILE *file, const DoubleLinkedList *node, int (*saveItem)(FILE *, const void *));

int loadDoubleListBinary(FILE *file, DoubleLinkedList **node, void * (*loadItem)(FILE *));

void saveDoubleList(FILE *file, const DoubleLinkedList *node, void (*saveItem)(FILE *, const void *));

DoubleLinkedList *loadDoubleList(FILE *file, void * (*loadItem)(FILE *));

void freeDoubleList(DoubleLinkedList **node, void (*freeItem)(void *));

#endif // DOUBLELINKEDLIST_H
