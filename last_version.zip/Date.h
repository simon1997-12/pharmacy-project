#ifndef DATE_H
#define DATE_H

#include <stdio.h>
#include <time.h>
#include "general.h"


typedef struct {
    int day;    
    int month;  
    int year;   
} Date;


void initDate(Date* date);

void currentDate(Date* date);

int checkDateValidity(Date* date);

int compareDates(const Date* date1, const Date* date2);

void printDate(const Date* date);

int saveDateToBinary(FILE* file, const Date* date);

int loadDateFromBinary(Date* date, FILE* file);

void saveDate(FILE* file, const Date* date);

void loadDate(FILE* file, Date* date);

#endif // DATE_H
