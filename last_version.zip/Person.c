#define _CRT_SECURE_NO_WARNINGS 
#include "Person.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

void initPerson(Person *person) {
    setPersonName(person);
    setPersonGender(person);
    setPersonId(person); 
    setPersonPhoneNumber(person); 
}

void setPersonName(Person *person) {
    char buffer[BUFFER_SIZE];
    printf("Enter person name: ");
    myGets(buffer);
    person->name = (char *) malloc(strlen(buffer) + 1);
    CHECK_ALLOC_VOID(person->name);
    strcpy(person->name, buffer);
}

void setPersonGender(Person *person) {
    char buffer[BUFFER_SIZE];
    printf("Enter person gender (Male, Female, Other): ");
    myGets(buffer);
    if (strcmp(buffer, "Male") == 0 ) {
        person->gender = MALE;
    } else if (strcmp(buffer, "Female") == 0) {
        person->gender = FEMALE;
    } else {
        person->gender = OTHER;
    }
}

void setPersonId(Person *person) {
    char buffer[BUFFER_SIZE];
    int valid = 0;

    while (!valid) {
        printf("Enter person ID(9 digits): ");
        myGets(buffer);

        
        valid = validatePersonId(buffer);

        if (valid) {
            strcpy(person->PersonId, buffer);
        } else {
            printf("Invalid person ID format. Please try again.\n");
        }
    }
}

int validatePersonId(const char *personId) {
    
    if (strlen(personId) != ID_LENGTH) {
        return 0;
    }

    
    for (int i = 0; i < ID_LENGTH; i++) {
        if (!isdigit(personId[i])) {
            return 0;
        }
    }

    
    return 1;
}

void setPersonPhoneNumber(Person *person) {
    char buffer[BUFFER_SIZE];
    int valid = 0;

    while (!valid) {
        printf("Enter person phone number (format 000-0000000): ");
        myGets(buffer);

        
        valid = validatePhoneNumber(buffer);

        if (valid) {
            strcpy(person->phoneNumber, buffer);
        } else {
            printf("Invalid phone number format. Please try again.\n");
        }
    }
}

int validatePhoneNumber(const char *phoneNumber) {
    
    if (strlen(phoneNumber) != PHONE_NUMBER_LENGTH) {
        return 0;
    }

    
    for (int i = 0; i < PHONE_NUMBER_LENGTH; i++) {
        if (i == 3) {
            
            if (phoneNumber[i] != '-') {
                return 0;
            }
        } else {
            
            if (!isdigit(phoneNumber[i])) {
                return 0;
            }
        }
    }

    
    return 1;
}

int savePersonToBinaryFileCompressed(FILE *file, const Person *person) {
    
    BYTE data[2] = {0};
    int nameLength = (int) strlen(person->name);
    int personGender = (int) person->gender;
   
    data[0] = (BYTE) nameLength;
   
    data[1] = (BYTE) (personGender << 2);
    if (fwrite(data, sizeof(BYTE), 2, file) != 2)
        return 0;
    if (fwrite(person->name, sizeof(char), nameLength, file) != nameLength)
        return 0;
    if (fwrite(person->PersonId, sizeof(char), ID_LENGTH, file) != ID_LENGTH)
        return 0;
    if (fwrite(person->phoneNumber, sizeof(char), PHONE_NUMBER_LENGTH, file) != PHONE_NUMBER_LENGTH)
        return 0;
    return 1;
}

int loadPersonFromBinaryFileCompressed(Person *person, FILE *file) {
    BYTE data[2];
    if (fread(data, sizeof(BYTE), 2, file) != 2)
        return 0;
    int nameLength = (int) data[0];
    int gender = (int) (data[1] >> 2);
    

    person->name = (char *) malloc(nameLength);
    CHECK_ALLOC_INT(person->name);

    if (fread(person->name, sizeof(char), nameLength, file) != nameLength)
        return 0;
    
    if (fread(person->PersonId, sizeof(char), ID_LENGTH, file) != ID_LENGTH)
        return 0;
    

    if (fread(person->phoneNumber, sizeof(char), PHONE_NUMBER_LENGTH, file) != PHONE_NUMBER_LENGTH)
        return 0;

    
    person->name[nameLength] = '\0';
    person->PersonId[ID_LENGTH] = '\0';
    person->phoneNumber[PHONE_NUMBER_LENGTH] = '\0';

    person->gender = (Gender) gender;

    return 1;
}

void printPersonDetails(const Person *person) {
    printf("Person Details: ");
    printf(" | Name: %s | ", person->name);
    printf(" | Gender: %s | ", person->gender == MALE ? "Male " : person->gender == FEMALE ? "Female" : "Other ");
    printf(" | Person ID: %s | ", person->PersonId);
    printf(" | Phone Number: %s | ", person->phoneNumber);
}

int savePersonToBinary(FILE *file, const Person *person) {
    int nameLength = (int) (strlen(person->name)) + 1;
    if ((fwrite(&nameLength, sizeof(int), 1, file)) != SUCCESSPER)
        return 0;
    if ((fwrite(person->name, sizeof(char), nameLength, file)) != nameLength)
        return 0;
    int gender = (int) person->gender;
    if (fwrite(&gender, sizeof(int), 1, file) != 1)
        return 0;
    if ((fwrite(person->PersonId, sizeof(char), ID_LENGTH, file) != ID_LENGTH))
        return 0;
    if ((fwrite(person->phoneNumber, sizeof(char), PHONE_NUMBER_LENGTH, file) != PHONE_NUMBER_LENGTH))
        return 0;
    return 1;
}

int loadPersonFromBinary(Person *person, FILE *file) {
    int nameLength;
    if (fread(&nameLength, sizeof(int), 1, file) != SUCCESSPER) {
        printf("Error reading name length\n");
        return 0;
    }
    person->name = (char *) malloc(nameLength);
    CHECK_ALLOC_INT(person->name);
    if (fread(person->name, sizeof(char), nameLength, file) != nameLength)
        return 0;
    int gender;
    if (fread(&gender, sizeof(int), 1, file) != SUCCESSPER)
        return 0;
    person->gender = (Gender) gender;
    if (fread(person->PersonId, sizeof(char), ID_LENGTH, file) != ID_LENGTH)
        return 0;
    if (fread(person->phoneNumber, sizeof(char), PHONE_NUMBER_LENGTH, file) != PHONE_NUMBER_LENGTH)
        return 0;
    return 1;
}

void savePerson(FILE *file, const Person *person) {
    int nameLength = strlen(person->name) + 1;
    fprintf(file, "%d\n", nameLength);
    fprintf(file, "%s\n", person->name);
    fprintf(file, "%d\n", person->gender);
    fprintf(file, "%s\n", person->PersonId);
    fprintf(file, "%s\n", person->phoneNumber);
}

void loadPerson(Person *person, FILE *file) {
    int nameLength;
    (void)fscanf(file, "%d\n", &nameLength);
    person->name = (char *) malloc(nameLength);
    CHECK_ALLOC_VOID(person->name);
    (void)fscanf(file, "%s\n", person->name);
    (void)fscanf(file, "%u\n", &person->gender);
    (void)fscanf(file, "%s\n", person->PersonId);
    (void)fscanf(file, "%s\n", person->phoneNumber);
}

void freePerson(Person *person) {
    free(person->name);
    person->name = NULL;
}
