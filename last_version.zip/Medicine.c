#define _CRT_SECURE_NO_WARNINGS 
#include "Medicine.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void initMedicine(Medicine* medicine, const char* medicineID, int productCode) {
    
    initProduct(&medicine->product, 1,productCode);  

    
    strncpy(medicine->medicineID, medicineID, MEDICINE_ID_LENGTH);
    medicine->medicineID[MEDICINE_ID_LENGTH] = '\0';  

    
    setMedicineExpireDate(medicine);
    setMedicinePrescriptionRequired(medicine);
}

void setMedicineExpireDate(Medicine* medicine) {
    printf("Enter expiration date (e.g., DD/MM/YYYY): ");
    initDate(&medicine->expireDate);
}

void setMedicinePrescriptionRequired(Medicine* medicine) {
    printf("Is a prescription required for this medicine? (0 = No, 1 = Yes): ");
    (void)scanf("%d", &medicine->prescriptionRequired);
    clearInputBuffer();
}

void printMedicineInStock(const void* item) {
    const Medicine* medicine = (const Medicine*)item;
    if (medicine->product.stockQuantity > 0) {
        printMedicineDetails(medicine);
    }
}

void printMedicineDetails(const void* medicine) {
    const Medicine* med = (const Medicine*)medicine;
    
    printProductDetails(&med->product);

    printf("Expiration date:");
    printDate(&med->expireDate);
    printf("Prescription Required: %s\n", med->prescriptionRequired ? "Yes" : "No");
    printf("\n");
}

int saveMedicineToBinary(FILE* file, const void* medicine) {
    const Medicine* med = (const Medicine*)medicine;
    
    if (!saveProductToBinary(file, &med->product)) {
        return 0;
    }

    
    fwrite(med->medicineID, sizeof(char), MEDICINE_ID_LENGTH, file);
    saveDateToBinary(file, &med->expireDate);
    fwrite(&med->prescriptionRequired, sizeof(int), 1, file);

    return 1;
}

Medicine* loadMedicineFromBinary(FILE* file) {
    Medicine* medicine = (Medicine*)malloc(sizeof(Medicine));
    CHECK_ALLOC_STRUCT(medicine);

    
    Product* product = loadProductFromBinary(file);
    if (product == NULL) {
        free(medicine);
        return NULL;
    }
    medicine->product = *product;

    
    if (fread(medicine->medicineID, sizeof(char), MEDICINE_ID_LENGTH, file) != MEDICINE_ID_LENGTH) {
        free(product);
        free(medicine);
        return NULL;
    }
    if (!loadDateFromBinary(&medicine->expireDate, file)) {
        free(product);
        free(medicine);
        return NULL;
    }
    if (fread(&medicine->prescriptionRequired, sizeof(int), 1, file) != SUCCESSPRO) {
        free(product);
        free(medicine);
        return NULL;
    }

    return medicine;
}



void saveMedicine(FILE* file, const void* medicine) {
    const Medicine* med = (const Medicine*)medicine;
    
    saveProduct(file, &med->product);

    
    fprintf(file, "%s\n", med->medicineID);
    saveDate(file, &med->expireDate);
    fprintf(file, "%d\n", med->prescriptionRequired);
}

Medicine* loadMedicine(FILE* file) {
    Medicine* medicine = (Medicine*)malloc(sizeof(Medicine));
    CHECK_ALLOC_STRUCT(medicine);

    
    medicine->product = *loadProduct(file);

    
    (void)fscanf(file, "%s", medicine->medicineID);
    loadDate(file, &medicine->expireDate);
    (void)fscanf(file, "%d", &medicine->prescriptionRequired);

    return medicine;
}

void freeMedicine(void* medicine) {
    Medicine* med = (Medicine*)medicine;
    freeProduct(med);
}
