#ifndef ORDER_H
#define ORDER_H

#include "Product.h"
#include "Medicine.h"
#include "Date.h"
#include "Stock.h"
#include "Prescription.h"
#include "Employee.h"
#include <time.h>
#include "DoubleLinkedList.h"


typedef struct OrderProductNode {
    int productCode;                
    char* productName;              
    int price;                      
    int quantity;                    
} OrderProductNode;


typedef struct OrderMedicineNode {
    int medicineCode;               
    char* medicineName;              
    int price;                      
    int quantity;                    
} OrderMedicineNode;


typedef struct {
    int orderNumber;                  
    int customerID;                   
    LinkedList* orderProducts;  
    LinkedList* orderMedicines;  
    int totalAmount;                  
    Date lastModified;               
    Employee* employee;                   
} Order;


int isMedicineInOrder(Order* order, int medicineCode);

void initOrder(Order* order, int customerID, Employee* employee, int orderNumber);

void showOrder(const void* order);

void showAvailableProducts(Stock* stock, Order* order);

int addProductToOrder(Order* order, Stock* stock, Product* product, int quantity);

int addMedicineToOrder(Order* order, DoubleLinkedList * prescriptions, Stock* stock, Medicine* medicine, int customerID);

int updateProductQuantityInOrder(Stock* stock, Order* order, int productCode, int newQuantity);

int removeProductFromOrder(Order* order, int productCode);

void showOrdersHistoryByDate(const LinkedList* orders);

void updateLastModified(Order* order);

void updateEmployeeInOrder(Order* order, Employee* newEmployee);

void printOrderProductNode(const void* data);

void printOrderMedicineNode(const void* data);

int compareOrderProductNodes(void* order, void* orderNumber);

void removeProductFromOrderClient(Order* order);

int saveOrderToBinary(FILE* file, const void* data);

void saveOrderProductNode(FILE* file, const void* data);

void saveOrderMedicineNode(FILE* file, const void* data);

int saveOrderMedicineNodeToBinary(FILE* file, const void* item);

int saveOrderProductToBinary(FILE* file, const void* item);

void* loadOrderProductNode(FILE* file);

void* loadOrderMedicineNode(FILE* file);

void* loadOrderProductNodeFromBinary(FILE* file);

void* loadOrderMedicineNodeFromBinary(FILE* file);

Order* loadOrderFromBinary(FILE* file, Employee** employees, int numEmployees);

void saveOrder(FILE* file, const void* data);

Order* loadOrder(FILE* file, Employee** employees, int numEmployees);

void freeOrderProductNode(void* data);

void freeOrderMedicineNode(void* data);

void freeOrder(void* order);



#endif // ORDER_H
