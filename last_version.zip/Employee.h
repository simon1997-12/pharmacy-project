#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include "general.h"  
#include "Person.h"   


typedef struct {
    Person person;    
    int id;           
    char* position;   
    double salary;    
} Employee;


void initEmployee(Employee* employee, int lastEmployeeID);

void setEmployeePosition(Employee* employee);

void setEmployeeSalary(Employee* employee);

void raiseSalary(Employee* employee, double raisePercentage);

Employee* findEmployee(Employee** employees, int numEmployees, int id);

void printEmployeeDetails(const Employee* employee);

int saveEmployeeToBinary(FILE* file, const Employee* employee);

int loadEmployeeFromBinary(Employee* employee, FILE* file);

void saveEmployee(FILE* file, const Employee* employee);

Employee* loadEmployee(FILE* file);

void freeEmployee(Employee* employee);

void freeEmployees(Employee** employees, int numEmployees);

#endif // EMPLOYEE_H
