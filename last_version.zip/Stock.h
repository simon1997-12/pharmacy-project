#ifndef STOCK_H
#define STOCK_H

#include "Product.h"  
#include "Medicine.h"
#include "LinkedList.h"
#define SUCCESS 1

typedef struct Stock {
    int lastProductCode;  
    Product* products;   
    int productCount;    

    Medicine* medicines;   
    int medicineCount;    

} Stock;

typedef int (*ArrayItemFunction)(void*, void*);

void freeStockMedicines(Stock* stock);

void freeStockProducts(Stock* stock);

void loadMedicines(FILE* file, Stock* stock);

int OperationLoadMedicine(void* medicine, void* arg);

void loadProducts(FILE* file, Stock* stock);

int OperationLoadProduct(void* product, void* arg);

void saveMedicines(FILE* file, const Medicine* medicines, int medicineCount);

int OperationSaveMedicine(void* medicine, void* arg);

void saveProducts(FILE* file, const Product* products, int productCount);

int OperationSaveProduct(void* product, void* arg);

int loadMedicinesFromBinary(FILE* file, Stock* stock);

int OperationLoadMedicineFromBinary(void* medicine, void* arg);

int loadProductsFromBinary(FILE* file, Stock* stock);

int OperationLoadProductFromBinary(void* product, void* arg);

int saveMedicinesToBinary(FILE* file, const Medicine* medicines, int medicineCount);

int OperationSaveMedicineToBinary(void* medicine, void* arg);

int saveProductsToBinary(FILE* file, const Product* products, int productCount);

int OperationSaveProductToBinary(void* product, void* arg);

void updateMedicineStock(Stock* stock, char* medicineID, int quantity);

int compareMedicineByCode(const void* a, const void* b);

int OperationPrintProduct(Product* product, void* arg);

int iterateArray(void* array, const int size, const int n, ArrayItemFunction operation, void* arg);

void initStock(Stock* stock);

Product* findProduct(const Stock* stock, int code);

int OperationPrintMedicine(Medicine* medicine, void* arg);

void printStockDetails(const Stock* stock);

void decreaseStockQuantity(Stock* stock, int productCode, int quantity);

void updateStock(Stock* stock, int productCode, int quantity);

Medicine* findMedicine(const Stock* stock, int code);

Medicine* findMedicineByID(Stock* stock, const char* medicineID);

void addNewProductToStock(Stock* stock);

void addNewMedicineToStock(Stock* stock);

int compareMedicineByID(const void* a, const void* b);

int compareProductByID(const void* a, const void* b);

int compareProductByName(const void* a, const void* b);

int compareProductByPrice(const void* a, const void* b);

void sortProductInStock(Stock* stock);

void findProductInStockBSearch(Stock* stock);

int saveStockToBinary(const Stock *stock, FILE *file);

int loadStockFromBinary(FILE* file, Stock* stock);

void saveStock(const Stock* stock, FILE* file);

void loadStock(FILE* file, Stock* stock);

void freeStock(Stock* stock);


#endif // STOCK_H
