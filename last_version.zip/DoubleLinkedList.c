#define _CRT_SECURE_NO_WARNINGS 
#include "DoubleLinkedList.h"
#include <stdlib.h>


void addToDoubleList(DoubleLinkedList **node, void *item) {
    DoubleLinkedList *newNode = (DoubleLinkedList *) malloc(sizeof(DoubleLinkedList));
    if (newNode != NULL) {

        newNode->item = item;
        newNode->next = *node;
        newNode->prev = NULL;

        if (*node != NULL)
            (*node)->prev = newNode;
        *node = newNode;
    }

}

void *removeFromDoubleList(DoubleLinkedList **node, int (*compare)(void *, void *), void *item) {
    DoubleLinkedList **current = node;
    while (*current != NULL) {
        if (compare((*current)->item, item) == 0) {
            DoubleLinkedList *temp = *current;
            if (temp->prev != NULL)
                temp->prev->next = temp->next;
            if (temp->next != NULL)
                temp->next->prev = temp->prev;
            if (*current == *node)
                *node = temp->next;
            void *removedItem = temp->item;
            free(temp);
            return removedItem;
        }
        current = &(*current)->next;
    }
    return NULL;
}

void *findInDoubleList(const DoubleLinkedList *node, int (*compare)(void *, void *), void *item) {
    while (node != NULL) {
        if (compare(node->item, item) == 0)
            return node->item;
        node = node->next;
    }
    return NULL;
}

int sizeOfDoubleList(const DoubleLinkedList *node) {
    int size = 0;
    while (node != NULL) {
        size++;
        node = node->next;
    }
    return size;
}

void printDoubleList(const DoubleLinkedList *node, void (*printItem)(const void *)) {
    while (node != NULL) {
        printItem(node->item);
        node = node->next;
    }
}

int saveDoubleListBinary(FILE *file, const DoubleLinkedList *node, int (*saveItem)(FILE *, const void *)) {
    const int size = sizeOfDoubleList(node);
    if (fwrite(&size, sizeof(int), 1, file) != SUCCESSDOUBLE)
        return 0;

    while (node != NULL) {
        if (!saveItem(file, node->item)) 
        {
            return 0;
        }
        node = node->next;
    }

    return 1;
}

int loadDoubleListBinary(FILE *file, DoubleLinkedList **node, void *(*loadItem)(FILE *)) {
    int size;
    if (fread(&size, sizeof(int), 1, file) != SUCCESSDOUBLE) 
    {
        return 0;
    }
    for (int i = 0; i < size; i++) {
        void *item = loadItem(file);
        if (item == NULL) 
        {
            return 0;
        }
        addToDoubleList(node, item);
    }

    return 1;
}

void saveDoubleList(FILE *file, const DoubleLinkedList *node, void (*saveItem)(FILE *, const void *)) {
    fprintf(file, "%d\n", sizeOfDoubleList(node));
    while (node != NULL) {
        saveItem(file, node->item);
        node = node->next;
    }
}

DoubleLinkedList *loadDoubleList(FILE *file, void *(*loadItem)(FILE *)) {
    DoubleLinkedList *node = NULL;
    int size;
    if (fscanf(file, "%d", &size) != SUCCESSDOUBLE) 
    {
        return NULL;
    }
    for (int i = 0; i < size; i++) {
        void *item = loadItem(file);
        if (item == NULL) 
        {
            freeDoubleList(&node, NULL);
            return NULL;
        }
        addToDoubleList(&node, item);
    }

    return node;
}



void freeDoubleList(DoubleLinkedList **node, void (*freeItem)(void *)) {
    if (node == NULL || *node == NULL) 
    {
        return;
    }
        DoubleLinkedList* current = *node;
        while (current != NULL) {
            DoubleLinkedList* temp = current;
            current = current->next;
            if (freeItem != NULL) 
            {
                freeItem(temp->item);
            }
            free(temp);
            
        }
        
        *node = NULL;
    
}
