#ifndef PRODUCT_H
#define PRODUCT_H

#include "general.h"
#define SUCCESSPRO 1
#define PRODUCT_TYPE_COUNT 3  

typedef enum {
    MEDICINE,
    HEALTHCARE, 
    EQUIPMENT   
    
} ProductType;


typedef struct {
    int code;           
    char* name;         
    ProductType type;   
    double price;      
    int stockQuantity;  
} Product;


void initProduct(Product* product, int isMedicine, int productCode);

void setProductName(Product* product);

void setProductType(Product* product);

void setProductPrice(Product* product);

void setProductStockQuantity(Product* product);

void printProductDetails(const Product* product);

void printProduct(const void* item);

void printProductInStock(const void* item);

int compareProducts(void* a, void* b);

int saveProductToBinary(FILE* file, const void* prod);

Product* loadProductFromBinary(FILE* file);

void saveProduct(FILE* file, const void* product);

Product* loadProduct(FILE* file);

void freeProduct(void* product);



#endif // PRODUCT_H
