#ifndef MEDICINE_H
#define MEDICINE_H

#include "Product.h"  
#include "Date.h"     
#define MEDICINE_ID_LENGTH 6


typedef struct {
    Product product;            
    char medicineID[MEDICINE_ID_LENGTH+1];         
    Date expireDate;           
    int prescriptionRequired;   
} Medicine;


void initMedicine(Medicine* medicine, const char* medicineID, int productCode);

void setMedicineExpireDate(Medicine* medicine);

void setMedicinePrescriptionRequired(Medicine* medicine);

void printMedicineInStock(const void* item);

void printMedicineDetails(const void* medicine);

int saveMedicineToBinary(FILE* file, const void* medicine);

Medicine* loadMedicineFromBinary(FILE* file);

void saveMedicine(FILE* file, const void* medicine);

Medicine* loadMedicine(FILE* file);

void freeMedicine(void* medicine);



#endif // MEDICINE_H
