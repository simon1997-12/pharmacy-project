#define _CRT_SECURE_NO_WARNINGS 
#include "Menu.h"
#include <stdio.h>
#include <stdlib.h>

void printMainMenu() {
    printf("\nMain Menu\n");
    printf("---------\n");
    printf("1. Prescription Management\n");
    printf("2. Stock Management\n");
    printf("3. Staff Management\n");
    printf("4. Order Management\n");
    printf("5. Show Menu\n");
    printf("-1. Exit\n");
    printf("Enter your choice: ");
}

void manageMainMenu(Pharmacy* pharmacy){
    int choice;
    do {
        printMainMenu();
        (void)scanf("%d", &choice);
        clearInputBuffer();

        switch (choice) {
            case 1:
                managePrescriptions(pharmacy);  
                break;
            case 2:
                menageStock(pharmacy);  
                break;
            case 3:
                manageStaff(pharmacy);  
                break;
            case 4:
                manageOrder(pharmacy);  
                break;
            case 5:
                showMenu(pharmacy);  
                break;
            case -1:
                break;  
            default:
                printf("Invalid choice, please try again.\n");
        }
    } while (choice != -1);  
}

void printOrderManagementMenu() {
    printf("\nOrder Management Menu\n");
    printf("---------------------\n");
    printf("1. Add Product/Medicine to Order\n");
    printf("2. Remove Product from Order\n");
    printf("3. Update Quantity of Product in Order\n");
    printf("4. Replace Employee\n");
    printf("5. Purchase Order\n");
    printf("6. Cancel Order\n");
    printf("Enter your choice: ");
}

void manageOrder(Pharmacy* pharmacy) {
    Order* order = createNewOrderInteractive(pharmacy);  
    CHECK_ALLOC_VOID(order);

    int choice;
    do {
        printOrderManagementMenu();
        (void)scanf("%d", &choice);
        clearInputBuffer();

        switch (choice) {
            case 1:
                printf("\n");
                addProductOrMedicineToOrder(pharmacy, order);  
                break;
            case 2:
                printf("\n");
                removeProductFromOrderClient(order);  
                break;
            case 3:
                printf("\n");
                updateProductQuantityOrder(pharmacy,order);  
                break;
            case 4:
                printf("\n");
                replaceEmployeeInOrder(pharmacy, order);  
                break;
            case 5:
                printf("\n");
                purchaseOrder(pharmacy, order);
                break;  
            case 6:
                cancelOrder(order);
                break;  
            default:
                printf("Invalid choice, please try again.\n");
        }
    } while (choice != 5 && choice != 6);  
}

void printStockManagementMenu() {
    printf("\nStock Management Menu\n");
    printf("---------------------\n");
    printf("1. Add New Product\n");
    printf("2. Add New Medicine\n");
    printf("3. Show and Update Stock\n");
    printf("4. Sort Stock\n");
    printf("5. Find Product In Stock Using BSearch\n");
    printf("-1. Back to Main Menu\n");
    printf("Enter your choice: ");
}

void menageStock(Pharmacy* pharmacy) {
    int choice;
    do {
        printStockManagementMenu();
        (void)scanf("%d", &choice);
        clearInputBuffer();

        switch (choice) {
            case 1:
                addNewProductToStock(&pharmacy->stock);  
                break;
            case 2:
                addNewMedicineToStock(&pharmacy->stock);  
                break;
            case 3:
                showAndUpdateStock(pharmacy);  
                break;
            case 4:
                sortProductInStock(&pharmacy->stock);  
                break;
            case 5:
                findProductInStockBSearch(&pharmacy->stock);  
                break;
            case -1:
                break;  
            default:
                printf("Invalid choice, please try again.\n");
        }
    } while (choice != -1);  
}


void printStaffManagementMenu() {
    printf("\nStaff Management Menu\n");
    printf("---------------------\n");
    printf("1. Add Employee\n");
    printf("2. Add Customer\n");
    printf("3. Remove Employee\n");
    printf("4. Raise Salary\n");
    printf("-1. Back to Main Menu\n");
    printf("Enter your choice: ");
}

void manageStaff(Pharmacy* pharmacy) {
    int choice;
    do {
        printStaffManagementMenu();
        (void)scanf("%d", &choice);
        clearInputBuffer();

        switch (choice) {
            case 1:
                addEmployeeInteractive(pharmacy);  
                break;
            case 2:
                addCustomerInteractive(pharmacy);  
                break;
            case 3:
                removeEmployeeInteractive(pharmacy);  
                break;
            case 4:
                raiseSalaryClient(pharmacy);  
                break;
            case -1:
                break;  
            default:
                printf("Invalid choice, please try again.\n");
        }
    } while (choice != -1);  
}


void printPrescriptionManagementMenu() {
    printf("\nPrescription Management Menu\n");
    printf("---------------------------\n");
    printf("1. Add New Prescription\n");
    printf("2. Show Prescriptions\n");
    printf("-1. Back to Main Menu\n");
    printf("Enter your choice: ");
}

void managePrescriptions(Pharmacy* pharmacy) {
    int choice;
    do {
        printPrescriptionManagementMenu();
        (void)scanf("%d", &choice);
        clearInputBuffer();

        switch (choice) {
            case 1:
                addNewPrescriptionToPharmacy(pharmacy);  
                break;
            case 2:
                printf("\n");
                printDoubleList(pharmacy->prescriptions, printPrescription);  
                break;
            case -1:
                break;  
            default:
                printf("Invalid choice, please try again.\n");
        }
    } while (choice != -1);  
}

void printShowMenu() {
    printf("\nShow Menu\n");
    printf("---------\n");
    printf("1. Show All Orders\n");
    printf("2. Show All Employees\n");
    printf("3. Show All Customers\n");
    printf("4. Show All Prescriptions\n");
    printf("5. Show All Stock\n");
    printf("6. Show Orders by Dates\n");
    printf("7. Show Orders by customer\n");
    printf("8. Show Pharmacy Information\n");
    printf("-1. Back to Main Menu\n");
    printf("Enter your choice: ");
}

void showMenu(Pharmacy* pharmacy) {
    int choice;
    do {
        printShowMenu();
        (void)scanf("%d", &choice);
        clearInputBuffer();

        switch (choice) {
            case 1:
                printf("\n");
                printAllOrders(&pharmacy->orderHistory);  
                break;
            case 2:
                printf("\n");
                printAllEmployees(pharmacy);  
                break;
            case 3:
                printf("\n");
                printAllCustomers(pharmacy);  
                break;
            case 4:
                printf("\n");
                printDoubleList(pharmacy->prescriptions, printPrescription);  
                break;
            case 5:
                printf("\n");
                printStockDetails(&pharmacy->stock);  
                break;
            case 6:
                printf("\n");
                showOrdersHistoryByDate(&pharmacy->orderHistory);  
                break;
            case 7:
                printf("\n");
                showOrdersByCustomer(pharmacy);  
                break;
            case 8:
                printf("\n");
                printPharmacyDetails(pharmacy);  
                break;
            case -1:
                break;  
            default:
                printf("Invalid choice, please try again.\n");
        }
    } while (choice != -1);  
}