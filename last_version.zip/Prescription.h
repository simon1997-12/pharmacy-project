#ifndef PRESCRIPTION_H
#define PRESCRIPTION_H

#include "general.h"  
#include "Date.h"    
#include "Medicine.h"
#include "Customer.h"
#include "Stock.h"


typedef struct {
    int id;                            
    Customer* customer;          
    char medicineID[MEDICINE_ID_LENGTH+1];                
    Date expirationDate;               
    int quantity;                      
    int used;                        
} Prescription;


void initPrescription(Prescription *prescription, Customer *customers, int numCustomers, int customerID, const char *medicineID, Date
                      expirationDate, int quantity, int prescriptionID);

int customerHasValidPrescription(const Prescription* prescriptions, int numPrescriptions, int customerID, const char* medicineID);

void printPrescription(const void *prescription);

int savePrescriptionToBinary(FILE* file, const void *prescription);

int loadPrescriptionFromBinary(Prescription *prescription, FILE *file, Customer *customers, int numCustomers);

void savePrescription(FILE* file, const void *prescription);

Prescription* loadPrescription(FILE *file, Customer *customers, int numCustomers);

void freePrescription(void* prescription);

#endif // PRESCRIPTION_H
