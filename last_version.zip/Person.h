#ifndef PERSON_H
#define PERSON_H

#include "general.h"  
#include <ctype.h>    

#define ID_LENGTH 9
#define PHONE_NUMBER_LENGTH 11
#define SUCCESSPER 1


typedef unsigned char BYTE;

typedef enum {
    MALE,   
    FEMALE, 
    OTHER   
} Gender;


typedef struct {
    char* name;      
    Gender gender;   
    char PersonId[ID_LENGTH+1]; 
    char phoneNumber[PHONE_NUMBER_LENGTH+1]; 
} Person;


void initPerson(Person* person);

void setPersonName(Person* person);

void setPersonGender(Person* person);

void setPersonId(Person* person);

int validatePersonId(const char* personId);

void setPersonPhoneNumber(Person* person);

int validatePhoneNumber(const char* phoneNumber);

void printPersonDetails(const Person* person);

int savePersonToBinary(FILE* file, const Person* person);

int loadPersonFromBinary(Person* person, FILE* file);

int savePersonToBinaryFileCompressed(FILE* file, const Person* person);

int loadPersonFromBinaryFileCompressed(Person* person, FILE* file);

void savePerson(FILE* file, const Person* person);

void loadPerson(Person* person, FILE* file);

void freePerson(Person* person);


#endif // PERSON_H
