#ifndef GENERAL_H
#define GENERAL_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHECK_ALLOC_VOID(ptr) if ((ptr) == NULL) { perror("Failed to allocate memory"); return; }
#define CHECK_ALLOC_INT(ptr) if ((ptr) == NULL) { perror("Failed to allocate memory"); return 0; }
#define CHECK_ALLOC_STRUCT(ptr) if ((ptr) == NULL) { perror("Failed to allocate memory"); return NULL; }
#define BUFFER_SIZE 1024  
#define SUCCESSGEN 1

void myGets(char* buffer);

void clearInputBuffer();

void readString(FILE* file, char** str);

#endif // GENERAL_H
