#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include <stdlib.h>
#include <stdio.h>
#include "general.h"


typedef struct ListNode {
    void* item;               
    struct ListNode* next;    
} ListNode;


typedef struct {
    ListNode* head;           
    int size;                
} LinkedList;


void initList(LinkedList* list);

void addToList(LinkedList* list, void* item);

void* removeFromList(LinkedList* list, int (*compare)(void*, void*), void* item);

void printList(const LinkedList* list, void (*printItem)(const void*));

int saveListBinary(FILE* file, const LinkedList* list, int (*saveItem)(FILE*, const void*));

int loadListBinary(FILE* file, LinkedList* list, void* (*loadItem)(FILE*));

void saveList(FILE* file, const LinkedList* list, void (*saveItem)(FILE*, const void*));

LinkedList* loadList(FILE* file, void* (*loadItem)(FILE*));

void freeList(LinkedList* list, void (*freeItem)(void*));

#endif // LINKEDLIST_H
