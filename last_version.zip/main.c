#define _CRT_SECURE_NO_WARNINGS 
#include "Menu.h"
#include <stdio.h>


int main() {
    Pharmacy pharmacy;
    int option;
    printf("Do you want to load data from text file or binary file? (1 for text file, 2 for binary file): ");
    (void)scanf("%d", &option);
    clearInputBuffer();

    if (option == 1) { 
        if (!loadDataFromFile("pharmacy.txt", &pharmacy)) {
            printf("Error loading data from file. Initialize from client.\n");
            initPharmacyClient(&pharmacy);
        }
    } else if (option == 2) {
        if (!loadDataFromBinary("pharmacy.bin", &pharmacy)) {
            printf("Error loading data from binary file. Initialize from client.\n");
            initPharmacyClient(&pharmacy);
        }
    } else {
        printf("Invalid choice. Initialize from client.\n");
        initPharmacyClient(&pharmacy);
    }

    manageMainMenu(&pharmacy); 

    saveDataToFile("pharmacy.txt", &pharmacy); 
    saveDataToBinary("pharmacy.bin", &pharmacy); 
    freePharmacy(&pharmacy); 
    return 0;
}
