#ifndef PHARMACY_H
#define PHARMACY_H

#include "Address.h"
#include "Stock.h"
#include "Employee.h"
#include "Customer.h"
#include "Order.h"
#include "LinkedList.h"
#include "DoubleLinkedList.h"

typedef struct Pharmacy {
    char *name; 
    Address address; 
    Stock stock; 
    Employee **employees; 
    int employeeCount; 
    Customer *customers; 
    int customerCount; 
    LinkedList orderHistory; 
    DoubleLinkedList *prescriptions; 
} Pharmacy;



void loadPharmacyFromFile(FILE* file, Pharmacy* pharmacy);

int loadPharmacyFromBinary(FILE* file, Pharmacy* pharmacy);

void loadPrescriptionsFromBinary(FILE* file, DoubleLinkedList** node, Customer* customers, const int numCustomers);

void loadPrescriptions(FILE* file, DoubleLinkedList** node, Customer* customers, int numCustomers);

void loadOrdersFromBinary(FILE* file, const Employee** employees, int numEmployees, LinkedList* orders);

void loadOrders(FILE* file, const Employee** employees, int numEmployees, LinkedList* orders);

Customer* loadCustomersFromBinary(FILE* file, const int numCustomers);

Customer* loadCustomers(FILE* file, int numCustomers);

Employee** loadEmployeesFromBinary(FILE* file, int numEmployees);

Employee** loadEmployees(FILE* file, int numEmployees);

void savePharmacyToFile(FILE* file, const Pharmacy* pharmacy);

int savePharmacyToBinary(FILE* file, const Pharmacy* pharmacy);

void printEmployeesChoose(const Pharmacy* pharmacy);

void printCustomersChoose(const Pharmacy* pharmacy);

void initPharmacy(Pharmacy *pharmacy);

void initPharmacyClient(Pharmacy *pharmacy);

void setPharmacyName(char *name);

Order *createNewOrder(const Pharmacy *pharmacy, int customerID, int employeeID);

Order *createNewOrderInteractive(const Pharmacy *pharmacy);

void addEmployee(Pharmacy *pharmacy, const Employee *employee);

void addEmployeeInteractive(Pharmacy *pharmacy);

void addCustomerInteractive(Pharmacy *pharmacy);

void addCustomer(Pharmacy *pharmacy, const Customer *customer);

void removeEmployeeInteractive(Pharmacy *pharmacy);

void removeEmployee(Pharmacy *pharmacy, int employeeID);

int compareOrderNumber(void *order, void *orderNumber);

void cancelOrder(Order *order);

void purchaseOrder(Pharmacy *pharmacy, Order *order);

void addNewPrescriptionToPharmacy(Pharmacy *pharmacy);

void addProductOrMedicineToOrder(Pharmacy *pharmacy, Order *order);

void updateProductQuantityOrder(Pharmacy *pharmacy, Order *order);

void showAndUpdateStock(Pharmacy *pharmacy);

void raiseSalaryClient(const Pharmacy *pharmacy);

void replaceEmployeeInOrder(const Pharmacy *pharmacy, Order *order);

void printPharmacyDetails(const Pharmacy *pharmacy);

void printAllEmployees(const Pharmacy *pharmacy);

void printAllCustomers(const Pharmacy *pharmacy);

void showOrdersByCustomer(const Pharmacy *pharmacy);

void printAllOrders(const LinkedList *orders);

int saveDataToBinary(const char *filename, const Pharmacy *pharmacy);

int loadDataFromBinary(const char *filename, Pharmacy *pharmacy);

void saveDataToFile(const char *filename, const Pharmacy *pharmacy);

int loadDataFromFile(const char *filename, Pharmacy *pharmacy);

void freePharmacy(Pharmacy *pharmacy);

#endif // PHARMACY_H
