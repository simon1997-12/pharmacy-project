#ifndef CUSTOMER_H
#define CUSTOMER_H

#include "general.h"  
#include "Person.h"   


typedef struct {
    Person person; 
    int id;        
} Customer;

int compareCustomerByID(const void* a, const void* b);

void initCustomer(Customer* customer, int lastCustomerID);

Customer* findCustomerByID(Customer* customers, int numCustomers, int customerID);

void printCustomerDetails(const Customer* customer);

int saveCustomerToBinary(FILE* file, const Customer* customer);

Customer* loadCustomerFromBinary(FILE* file);

void saveCustomer(FILE* file, const Customer* customer);

Customer* loadCustomer(FILE* file);

void freeCustomer(Customer* customer);

void freeCustomers(Customer* customers, int numCustomers);

#endif // CUSTOMER_H
