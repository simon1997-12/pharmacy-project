#ifndef ADDRESS_H
#define ADDRESS_H

#include "general.h"  
#define POSTALSIZE 7

typedef struct {
    char* country;      
    char* city;         
    char* street;       
    int houseNumber;    
    char postalCode[POSTALSIZE]; 
} Address;


void setAddressCountry(Address* address);

void setAddressCity(Address* address);

void setAddressStreet(Address* address);

void setAddressHouseNumber(Address* address);

int setAddressPostalCode(Address* address);

void printAddressDetails(const Address* address);

void initAddress(Address* address);

int saveAddressToBinary(const Address* address, FILE* file);

int loadAddressFromBinary(Address* address, FILE* file);

void saveAddress(const Address* address, FILE* file);

void loadAddress(Address* address, FILE* file);

void freeAddress(Address* address);

#endif // ADDRESS_H
