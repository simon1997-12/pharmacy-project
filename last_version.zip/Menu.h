#ifndef MENU_H
#define MENU_H

#include "Pharmacy.h"
#include "Order.h"
#include "Stock.h"
#include "Employee.h"
#include "Customer.h"
#include "Prescription.h"
#include "Date.h"
#include "LinkedList.h"
#include <stdio.h>


void printMainMenu();

void manageMainMenu(Pharmacy* pharmacy);

void printOrderManagementMenu();

void manageOrder(Pharmacy* pharmacy);

void managePrescriptions(Pharmacy* pharmacy);

void menageStock(Pharmacy* pharmacy);

void manageStaff(Pharmacy* pharmacy);

void showMenu(Pharmacy* pharmacy);


#endif // MENU_H
